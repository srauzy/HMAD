# HMAD
Head Movements (and internal facial movements) Automatic Detection

The HMAD project aims at providing R script and source codes allowing automatic detection of internal facial movements and head movements from a video record.
